TheFixer Designs - Free Small Business Invoice Template
=====================================================

Thanks for downloading! This free workbook is a complete, working invoice + estimate:

- Invoice and Estimate tabs with automatic subtotal, discount, tax, total and balance due
- Services tab: enter your services and prices once, then pick them from a dropdown on every invoice
- Setup tab: your business name, contact details, tax rate and payment terms flow into every document
- Fillable PDF versions (Letter and A4) if you prefer to fill invoices in a PDF reader

Works in Microsoft Excel, Google Sheets (File > Import), Apple Numbers and LibreOffice.

Want one made for your trade?
TheFixer has invoice templates built for specific trades (plumbers, electricians, house cleaners,
detailers, dog walkers, groomers, trainers, photographers, lawn care and handymen) with the service
list already filled in, plus complete Business Kits with matching social media posts:
https://the-fixer.org

License: free to use for your own business. Please do not resell or redistribute this file.
Questions: eric@the-fixer.org

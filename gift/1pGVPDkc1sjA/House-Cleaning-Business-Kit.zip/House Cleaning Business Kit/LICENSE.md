# TheFixer digital asset license

One purchaser receives a nonexclusive license to edit and use the included assets in their own business, games, videos and creative productions, including commercial end products. No additional royalty is required for these permitted uses.

Do not resell, redistribute or sublicense the standalone assets or an asset pack containing them. Do not register an unchanged asset as a trademark. No exclusivity is granted. The seller retains any rights it holds; this license does not grant rights in material added by the purchaser. The purchaser is responsible for that added material.

These are ready-made digital files. Custom editing, guaranteed compatibility with every editor, and guaranteed business results are not included. Sounds in creator packs come from the same synthesis recipes as TheFixer's UI sound pack and are not exclusive.

For product support, contact TheFixer at eric@the-fixer.org or through the storefront where you purchased. Applicable marketplace rules and statutory rights still apply.

# House Cleaning Business Kit

Two TheFixer kits for house cleaners and cleaning services in one download:

## invoice/
House Cleaning Invoice Template - an Excel / Google Sheets / Numbers / LibreOffice workbook (Invoice, Estimate, Services price list,
Setup, How To Use) where totals, tax and balance due calculate for you, plus designed fillable PDFs in Letter and A4.
See invoice/README.md for step-by-step instructions.

## social-posts/
House Cleaning Service Posts - 8 editable SVG social media designs (4 square posts + 4 stories) with PNG previews. Two designs are
built around a photo frame (swap in your own photos) and two are bold graphic layouts. The fonts used are in
social-posts/fonts/ (SIL Open Font License). See social-posts/README.md.

Read LICENSE.md for permitted uses. Support: eric@the-fixer.org

MAKE IT YOURS (COLOURS + LOGO): every colour in these designs can be changed to match your own brand. The quick way is the
included brand-it.html: open it in any browser (it works offline and never uploads anything), drop in your logo, and your
brand colours are picked up and applied to every design; your logo is placed where the sample business name sits, and the
finished SVG and PNG files download in one go. You can also change any colour by hand in your vector editor: every shape and
text is a normal object with a plain colour value.

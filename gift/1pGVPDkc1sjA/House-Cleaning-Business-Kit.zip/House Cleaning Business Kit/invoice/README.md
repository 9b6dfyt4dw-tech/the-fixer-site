# House Cleaning Invoice Template

Premium editable invoice for house cleaners and cleaning services.

## What's included
- `house-cleaning-invoice-template.xlsx` - workbook with Invoice, Estimate, Services (price list), Setup and How To Use tabs.
- `house-cleaning-invoice-template-fillable-letter.pdf` and `house-cleaning-invoice-template-fillable-a4.pdf` - designed fillable PDFs; amounts, tax, total and balance calculate as you type.

## Quick start (spreadsheet)
1. Setup tab: enter your business details, tax rate and payment terms once.
2. Services tab: enter your prices (example services are already listed; add your own in the empty rows).
3. Invoice tab: pick each Item from the dropdown - description, unit and rate fill in. Type the quantity.
4. Enter the invoice number, date, client, and any discount or amount paid. Due date, tax, total and balance due calculate.
5. Print or save as PDF; the page is set to fit one sheet.

Formula cells are protected against accidental edits (Review > Unprotect Sheet, no password).
Works in Microsoft Excel, Google Sheets, Apple Numbers and LibreOffice.

## Fillable PDF
Open in Adobe Acrobat Reader (free), Microsoft Edge, Google Chrome or most PDF apps, type in the fields and save or print.
Enter rates as numbers (for example 95 or 95.50); amounts and totals calculate automatically.

This is a template, not tax, legal or accounting advice; check what your local rules require on an invoice.

COLOURS: the workbook's accent (the colour bar across the top and the INVOICE / ESTIMATE title) is a normal cell fill and font
colour. To match your brand, select those cells on the Invoice and Estimate tabs and pick your own colours (Excel: Home >
Fill Colour / Font Colour; Google Sheets: the paint-bucket and text-colour icons). Add your logo beside your business name
with Insert > Image. The fillable PDFs keep their printed design.

# House Cleaning Service Posts

Four ready-made social media designs for House cleaning services promoting weekly deep clean packages, each as a 1080x1080 post and a 1080x1920 story: 8 editable SVG files and 8 PNG previews.

FONTS: this pack uses Archivo Black and Inter. The font files are in the fonts folder (free SIL Open Font License; see OFL.txt in each font folder). Install them first (Windows: right-click > Install; Mac: double-click > Install Font), then open the SVGs so the text looks exactly like the previews.

PHOTOS: the photos in the previews are sample placeholders (original images made with a local AI image model). Replace them with your own photos: select the photo in your editor and use Replace / Relink, or delete it and place your own image in the same frame.

TEXT: all text is sample copy. Click any text to type your own business name, dates, services and contact details.

Open the SVGs in a vector editor (Inkscape is free; Illustrator and Affinity Designer work too) and export PNG or JPG for posting. No custom editing service is promised. Read LICENSE.md for permitted uses.

MAKE IT YOURS (COLOURS + LOGO): every colour in these designs can be changed to match your own brand. The quick way is the
included brand-it.html: open it in any browser (it works offline and never uploads anything), drop in your logo, and your
brand colours are picked up and applied to every design; your logo is placed where the sample business name sits, and the
finished SVG and PNG files download in one go. You can also change any colour by hand in your vector editor: every shape and
text is a normal object with a plain colour value.
